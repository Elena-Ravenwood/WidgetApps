package com.example.widgetapps_1617051113

class Constants {
  companion object {
    const val GRAMS_EXTRA = "COFFEE_GRAMS"
    const val ADD_COFFEE_INTENT = "ADD_COFFEE"
  }
}