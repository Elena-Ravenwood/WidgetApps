package com.example.widgetapps_1617051113

enum class CoffeeTypes(val grams: Int) {
  RISTRETTO(4),
  ESPRESSO(6),
  LONG(7)
}