package com.example.widgetapps_1617051113

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews


class CoffeeLoggerWidget : AppWidgetProvider() {

  override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
    val intent = Intent(context.applicationContext, CoffeeQuotesService::class.java)
    intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, appWidgetIds)
    context.startService(intent)
  }

  override fun onEnabled(context: Context) {

  }

  override fun onDisabled(context: Context) {

  }

  companion object {

    internal fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager,
                                 appWidgetId: Int) {

      val coffeeLoggerPersistence = CoffeeLoggerPersistence(context)

      val widgetText = coffeeLoggerPersistence.loadTitlePref().toString()


      val views = RemoteViews(context.packageName, R.layout.coffee_logger_widget)
      views.setTextViewText(R.id.appwidget_text, widgetText)

      views.setOnClickPendingIntent(R.id.ristretto_button,
          getPendingIntent(context, CoffeeTypes.RISTRETTO.grams))
      views.setOnClickPendingIntent(R.id.espresso_button,
          getPendingIntent(context, CoffeeTypes.ESPRESSO.grams))
      views.setOnClickPendingIntent(R.id.long_button,
          getPendingIntent(context, CoffeeTypes.LONG.grams))
      views.setTextViewText(R.id.coffee_quote, getRandomQuote(context))

      val limit = coffeeLoggerPersistence.getLimitPref(appWidgetId)
      val background = if (limit <= widgetText.toInt()) R.drawable.background_overlimit else R.drawable.background
      views.setInt(R.id.widget_layout, "setBackgroundResource", background)
      

      appWidgetManager.updateAppWidget(appWidgetId, views)
    }

    private fun getPendingIntent(context: Context, value: Int): PendingIntent {
      val intent = Intent(context, MainActivity::class.java)
      intent.action = Constants.ADD_COFFEE_INTENT
      intent.putExtra(Constants.GRAMS_EXTRA, value)
      return PendingIntent.getActivity(context, value, intent, 0)
    }

    private fun getRandomQuote(context: Context): String {
      val quotes = context.resources.getStringArray(R.array.coffee_texts)
      val rand = Math.random() * quotes.size
      return quotes[rand.toInt()].toString()
    }

  }
}

